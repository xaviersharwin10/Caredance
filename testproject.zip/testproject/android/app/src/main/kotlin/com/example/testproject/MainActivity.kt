package com.example.testproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
